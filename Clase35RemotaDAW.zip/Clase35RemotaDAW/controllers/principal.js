exports.getPrincipal=(req,res)=>{
    res.send('<h1>Página principal</h1>');
};